# frozen_string_literal: true

# module ArticlesHelper
module ArticlesHelper
end
