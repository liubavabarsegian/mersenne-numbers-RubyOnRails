# frozen_string_literal: true

# module ApplicationHelper
module ApplicationHelper
end
