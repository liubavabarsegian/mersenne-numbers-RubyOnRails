# frozen_string_literal: true

# class ArticlesController
class ArticlesController < ApplicationController
  def index; end
end
